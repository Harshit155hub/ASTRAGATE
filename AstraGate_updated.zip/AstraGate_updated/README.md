
# AstraGate Login

A futuristic animated login page created with HTML, CSS, and JavaScript.

## Features
- Animated background
- Smooth fade-in login form
- Responsive design
- Stylish futuristic theme

## How to Run
1. Download the project.
2. Open `index.html` in your browser.

---

Made with ❤️ by Harshit Malhotra
