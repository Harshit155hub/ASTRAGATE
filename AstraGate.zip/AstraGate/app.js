
document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Welcome to AstraGate! Authentication successful.');
});
